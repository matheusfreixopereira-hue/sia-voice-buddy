# SIA — Super IA Assistant

Assistente de inteligência artificial por voz em tempo real, usando WebRTC e OpenAI Realtime API.

## Recursos

- Conversa por voz em tempo real
- WebRTC com baixa latência
- VAD (detecção automática de fala)
- Interrupção/barging-in
- Transcrição opcional
- Histórico local de conversas
- Configuração de voz, idioma, personalidade e áudio
- Interface responsiva em português brasileiro

## Configuração

1. Instale as dependências.
2. Configure `OPENAI_API_KEY` como segredo no ambiente do servidor. **Nunca coloque essa chave em `VITE_*`.**
3. Se utilizar Supabase, preencha as variáveis correspondentes conforme `.env.example`.
4. Execute `npm run dev`.

## Produção

O segredo da OpenAI é usado somente no servidor para criar a sessão realtime efêmera. O navegador recebe apenas a credencial temporária necessária para o handshake WebRTC.
