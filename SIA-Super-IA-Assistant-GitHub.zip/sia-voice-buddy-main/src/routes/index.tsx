import { useEffect, useMemo, useState } from "react";
import { History, Settings, Sparkles } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ConnectionStatus } from "@/components/sia/ConnectionStatus";
import { ConversationHistory } from "@/components/sia/ConversationHistory";
import { SettingsDialog } from "@/components/sia/SettingsDialog";
import { SIAOrb } from "@/components/sia/SIAOrb";
import { TranscriptPanel } from "@/components/sia/TranscriptPanel";
import { VoiceButton } from "@/components/sia/VoiceButton";
import { useConversations } from "@/hooks/useConversations";
import { useRealtimeVoice } from "@/hooks/useRealtimeVoice";
import { useSettings } from "@/hooks/useSettings";
import type { TranscriptMessage } from "@/types/sia";

export const Route = createFileRoute("/")({ component: Index });

function Index() {
  const { settings, update } = useSettings();
  const {
    conversations,
    active,
    activeId,
    setActiveId,
    startNew,
    appendMessage,
    remove,
  } = useConversations();
  const [historyOpen, setHistoryOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const voice = useRealtimeVoice({ settings, onMessage: appendMessage });

  const messages = active?.messages ?? [];
  const hasConversation = messages.length > 0 || Boolean(voice.liveUserText || voice.liveAssistantText);

  const statusText = useMemo(() => {
    switch (voice.state) {
      case "CONNECTING": return "Conectando...";
      case "LISTENING": return "Estou ouvindo...";
      case "PROCESSING": return "Pensando...";
      case "SPEAKING": return "SIA está falando...";
      case "ERROR": return "Não consegui conectar";
      case "DISCONNECTED": return "Conexão perdida";
      default: return hasConversation ? "Pronta para continuar" : "Converse comigo por voz em tempo real";
    }
  }, [voice.state, hasConversation]);

  useEffect(() => {
    if (voice.error) {
      const timer = window.setTimeout(() => voice.clearError(), 7000);
      return () => window.clearTimeout(timer);
    }
  }, [voice.error, voice.clearError]);

  function handleNewConversation() {
    voice.stop();
    startNew();
    setHistoryOpen(false);
  }

  function handleSelectConversation(id: string) {
    if (id !== activeId) voice.stop();
    setActiveId(id);
    setHistoryOpen(false);
  }

  function handleDeleteConversation(id: string) {
    if (id === activeId) voice.stop();
    remove(id);
  }

  function handleStart() {
    if (voice.state === "SPEAKING") {
      voice.interrupt();
      return;
    }
    void voice.start();
  }

  return (
    <main className="ambient-bg relative min-h-svh overflow-hidden bg-background text-foreground">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_25%,color-mix(in_oklch,var(--background)_25%,transparent)_100%)]" />

      <header className="relative z-10 flex items-center justify-between px-5 py-5 sm:px-8 sm:py-7">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-2xl border border-border/80 bg-background/50 shadow-lg backdrop-blur-xl">
            <Sparkles className="size-5 text-primary" />
          </div>
          <div>
            <div className="font-display text-lg font-semibold tracking-tight">SIA</div>
            <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Super IA Assistant</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <ConnectionStatus state={voice.state} />
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setHistoryOpen(true)} aria-label="Abrir conversas">
            <History className="size-5" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setSettingsOpen(true)} aria-label="Abrir configurações">
            <Settings className="size-5" />
          </Button>
        </div>
      </header>

      <section className="relative z-10 mx-auto flex min-h-[calc(100svh-92px)] w-full max-w-5xl flex-col items-center justify-center px-5 pb-8 pt-2 sm:px-8">
        <div className="mb-3 text-center sm:mb-5">
          <p className="text-xs font-medium uppercase tracking-[0.25em] text-primary/80">{statusText}</p>
          {voice.error && (
            <button type="button" onClick={voice.clearError} className="mt-3 max-w-md text-sm text-destructive underline-offset-4 hover:underline">
              {voice.error}
            </button>
          )}
        </div>

        <div className="relative flex items-center justify-center py-3 sm:py-6">
          <SIAOrb state={voice.state} inputLevel={voice.inputLevel} outputLevel={voice.outputLevel} />
        </div>

        {!hasConversation && voice.state === "IDLE" && (
          <div className="mb-5 max-w-xl text-center">
            <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-5xl">Olá! Sou a SIA.</h1>
            <p className="mt-3 text-sm leading-6 text-muted-foreground sm:text-base">Fale naturalmente comigo. Eu escuto, respondo por voz e posso ser interrompida a qualquer momento.</p>
          </div>
        )}

        {settings.showTranscript && (
          <div className="mb-5 w-full max-w-2xl">
            <TranscriptPanel
              messages={messages}
              liveUserText={voice.liveUserText}
              liveAssistantText={voice.liveAssistantText}
            />
          </div>
        )}

        <VoiceButton
          state={voice.state}
          level={voice.state === "LISTENING" ? voice.inputLevel : voice.outputLevel}
          onStart={handleStart}
          onStop={voice.stop}
        />

        {voice.state === "ERROR" || voice.state === "DISCONNECTED" ? (
          <Button variant="ghost" className="mt-3" onClick={handleStart}>Reconectar</Button>
        ) : (
          <p className="mt-4 text-center text-[11px] text-muted-foreground">Microfone necessário · WebRTC · conversa em tempo real</p>
        )}
      </section>

      <ConversationHistory
        open={historyOpen}
        onOpenChange={setHistoryOpen}
        conversations={conversations}
        activeId={activeId}
        onSelect={handleSelectConversation}
        onDelete={handleDeleteConversation}
        onNew={handleNewConversation}
      />

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} settings={settings} onChange={update} />
    </main>
  );
}
